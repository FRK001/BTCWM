# BTCWM -> BTCWalletMiner
> A tool created to mine bitcoin wallets.

<p align="center">
	<img src="https://img.shields.io/badge/Made%20in-C%23-brightgreen" alt="Badge 1"/>
	<img src="https://img.shields.io/badge/Made%20with-%3C3-ff69b4" alt="Badge 2"/>
	<img src="https://img.shields.io/github/v/release/schwaaaa/BTCWalletMiner?color=%23004440&include_prereleases" alt="Badge 3"/>
	<img src="https://img.shields.io/github/last-commit/schwaaaa/BTCWalletMiner" alt="Badge 4"/>
</p>

## Table of Contents
* [Introduction](#introduction)
* [Setup](#setup)
* [Usage](#usage)

## Introduction
To ensure that the future of BTC and BTC wallets can thrive, I've created a tool to test this.

## Setup
<p><i>TODO: Implement<p></p>

## Usage
<p><i>TODO: Implement<p></p>
